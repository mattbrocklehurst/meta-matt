
=======================================================================
            __
           /  \    Apache
          /    \__________________________________
         /  /\  \  \/  /    \ |  |  /   \|   \|  |
        /  /  \  \    /  /\  \|  |_|  O  |  \ \  |
       /__/    \__\__/__/  \__\_____\__ /|__|\___|


                         == Avalon-LogKit ==

=======================================================================
summary:   The Avalon-LogKit logging utility
publisher: Apache Software Foundation
website:   http://avalon.apache.org/
version:   1.2.2
license:   Please see the LICENSE.txt file
=======================================================================

Avalon LogKit is the logging utility used by default in all Avalon systems.

More documentation?
===================
We do not distribute all our documentation through releases. Rather,
you are encouraged to visit our website at
    http://avalon.apache.org/
for more information.

Building from source?
=====================
The avalon buildfiles use a common buildsystem which utilizes maven and
forrest. You will need to download and install maven, the
maven-forrest-plugin, and the avalon-buildsystem module.
